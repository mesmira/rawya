// @dart=2.9
import 'package:flutter/material.dart';
import 'package:rawya/database/db_medecament.dart';
import 'package:rawya/databaseOperation/medDbOp.dart';
import 'package:rawya/model/medModel.dart';

class AddMed extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _AddMedState();
}

class _AddMedState extends State<AddMed> {
  final _medCode = TextEditingController();
  final _medName = TextEditingController();
  final _laboName = TextEditingController();

  List<MedModel> medItems = new List();

  MedDbOp medDbOp = new MedDbOp();

  @override
  void initState() {
    super.initState();
    medDbOp.getAllMeds().then((med) {
      setState(() {
        med.forEach((med) {
          medItems.add(MedModel.fromMap(med));
        });
      });
    });
  }

  final _formAddUserKey = GlobalKey<FormState>();
  //////////////////////////////////////
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //   resizeToAvoidBottomInset: false,
      appBar: AppBar(title: Text('اضافة دواء جديد')),
      body: Container(
        margin: EdgeInsets.all(15.0),
        alignment: Alignment.center,
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Form(
            key: _formAddUserKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TextFormField(
                    keyboardType: TextInputType.text,
                    controller: _medCode,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Med Code',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'entrer Med Code';
                      }
                      return null;
                    },
                  ),
                  Padding(padding: new EdgeInsets.all(5.0)),
                  TextFormField(
                    keyboardType: TextInputType.text,
                    controller: _medName,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Med Name',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'entrer Med Nom';
                      }
                      return null;
                    },
                  ),
                  Padding(padding: new EdgeInsets.all(5.0)),
                  TextFormField(
                    keyboardType: TextInputType.text,
                    controller: _laboName,
                    decoration: InputDecoration(
                      labelText: 'Labo Nom',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'entrer Labo Nom';
                      }
                      return null;
                    },
                  ),
                  Padding(padding: new EdgeInsets.all(5.0)),
                  Container(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all<Color>(Colors.redAccent),
                      ),
                      onPressed: () {
                        if (_formAddUserKey.currentState.validate()) {
                          medDbOp
                              .addMed(MedModel(
                            _medCode.text,
                            _medName.text,
                            _laboName.text,
                          ))
                              .then((_) {
                            Navigator.pop(context, 'save');
                          });
                        }
                        print('---------all is good-----------');
                      },
                      child: Text(
                        'Enregistrer',
                        textAlign: TextAlign.center,
                        textScaleFactor: 1.1,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
