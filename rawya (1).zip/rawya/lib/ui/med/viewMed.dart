// @dart=2.9
import 'package:flutter/material.dart';
import 'package:rawya/ui/home/listSearchPage.dart';
import 'package:rawya/model/medModel.dart';

class ViewMed extends StatefulWidget {
  final MedModel med;

  ViewMed(this.med);

  @override
  State<StatefulWidget> createState() => new _ViewMedState();
}

class _ViewMedState extends State<ViewMed> {
  TextEditingController _medCodeController;
  TextEditingController _medNameController;
  TextEditingController _laboNameController;

  @override
  void initState() {
    super.initState();

    _medCodeController = new TextEditingController(text: widget.med.medCode);
    _medNameController = new TextEditingController(text: widget.med.medName);
    _laboNameController = new TextEditingController(text: widget.med.laboName);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('View ' + widget.med.medName),
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            child: Card(
              color: Colors.blueAccent,
              child: ListTile(
                selected: true,
                trailing: Text(
                  _medCodeController.text,
                  textAlign: TextAlign.right,
                  textScaleFactor: 1.5,
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                title: Text(
                  'Med Code',
                  textAlign: TextAlign.left,
                  textScaleFactor: 1.5,
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
          Container(
            width: double.infinity,
            child: Card(
              color: Colors.blueAccent,
              child: ListTile(
                selected: true,
                trailing: Text(
                  _medNameController.text,
                  textAlign: TextAlign.right,
                  textScaleFactor: 1.5,
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                title: Text(
                  'Med Nome',
                  textAlign: TextAlign.left,
                  textScaleFactor: 1.5,
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
          Container(
            width: double.infinity,
            child: Card(
              color: Colors.blueAccent,
              child: ListTile(
                selected: true,
                trailing: Text(
                  _laboNameController.text,
                  textAlign: TextAlign.right,
                  textScaleFactor: 1.5,
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                title: Text(
                  'Lab Nome',
                  textAlign: TextAlign.left,
                  textScaleFactor: 1.5,
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
