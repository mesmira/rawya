// @dart=2.9
import 'package:flutter/material.dart';
import 'package:rawya/databaseOperation/medDbOp.dart';
import 'package:rawya/model/medModel.dart';

class UpdateMed extends StatefulWidget {
  final MedModel med;

  UpdateMed(this.med);

  @override
  State<StatefulWidget> createState() => new _UpdateMedState();
}

class _UpdateMedState extends State<UpdateMed> {
  MedDbOp medDbOp = new MedDbOp();

  TextEditingController _medCodeController;
  TextEditingController _medNameController;
  TextEditingController _laboNameController;

  @override
  void initState() {
    super.initState();

    _medCodeController = new TextEditingController(text: widget.med.medCode);
    _medNameController = new TextEditingController(text: widget.med.medName);
    _laboNameController = new TextEditingController(text: widget.med.laboName);
  }

  final _formUpdateUserKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //    resizeToAvoidBottomInset: false,
      appBar: AppBar(title: Text('Update Med ' + _medNameController.text)),
      body: Container(
        margin: EdgeInsets.all(15.0),
        alignment: Alignment.center,
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Form(
            key: _formUpdateUserKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  TextFormField(
                    keyboardType: TextInputType.text,
                    controller: _medCodeController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Med Code',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'entrer Med Code';
                      }
                      return null;
                    },
                  ),
                  Padding(padding: new EdgeInsets.all(5.0)),
                  TextFormField(
                    keyboardType: TextInputType.text,
                    controller: _medNameController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Med Name',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'entrer Med Nom';
                      }
                      return null;
                    },
                  ),
                  Padding(padding: new EdgeInsets.all(5.0)),
                  TextFormField(
                    keyboardType: TextInputType.text,
                    controller: _laboNameController,
                    decoration: InputDecoration(
                      labelText: 'Labo Nom',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'entrer Labo Nom';
                      }
                      return null;
                    },
                  ),
                  Padding(padding: new EdgeInsets.all(5.0)),
                  Container(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all<Color>(Colors.green),
                      ),
                      onPressed: () {
                        if (_formUpdateUserKey.currentState.validate()) {
                          if (widget.med.medId != null) {
                            medDbOp
                                .updateMed(MedModel.fromMap({
                              'medId': widget.med.medId,
                              'medCode': _medNameController.text,
                              'medName': _medCodeController.text,
                              'laboName': _laboNameController.text,
                            }))
                                .then((_) {
                              Navigator.pop(context, 'update');
                            });
                          }
                        }
                      },
                      child: Text(
                        'Update',
                        textAlign: TextAlign.center,
                        textScaleFactor: 1.1,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
