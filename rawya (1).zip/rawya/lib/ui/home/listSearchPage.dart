// @dart=2.9
//import 'package:bbt/ui/users/viewUser.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
//import 'package:bbt/player.dart';
import 'package:rawya/model/medModel.dart';

class ListSearchPage extends SearchDelegate<String> {
  List<MedModel> listusers;
  List<String> list;
  String select;

  ListSearchPage(this.list, this.listusers);

  @override
  appBarTheme(BuildContext context) {
    return Theme.of(context);
  }

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.close),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        close(context, '');
      },
    );
  }

  //***************************************************hadi ki tlad serch
  @override
  Widget buildResults(BuildContext context) {
    var filterList = list.where((String s) => s.contains(query.trim()));
    return ListView(
      children: <Widget>[
        for (String item in filterList)
          //    if(2>1){}
          ListTile(
            leading: FaIcon(
              FontAwesomeIcons.user,
              size: 25,
              color: Colors.purple,
            ),
            title: Text(
              item,
              style: Theme.of(context).textTheme.title,
            ),
            onTap: () {
              listusers.forEach((i) {
                if (i.medName == item) {
                  //         Navigator.push(context, MaterialPageRoute(builder: (context) => ViewUser(i)));
                }
              });
            },
          ),
      ],
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    var filterList = list.where((String s) => s.contains(query.trim()));
    return ListView(
      children: <Widget>[
        for (String item in filterList)
          ListTile(
            leading: FaIcon(
              FontAwesomeIcons.user,
              size: 25,
              color: Colors.purple,
            ),
            title: Text(
              item,
              style: Theme.of(context).textTheme.title,
            ),
            onTap: () {
              listusers.forEach((i) {
                if (i.medName == item) {
                  //     Navigator.push(context, MaterialPageRoute(builder: (context) => ViewUser(i)));
                }
              });
            },
          ),
      ],
    );
  }
}
