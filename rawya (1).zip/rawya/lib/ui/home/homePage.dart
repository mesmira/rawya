// @dart=2.9

import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:rawya/databaseOperation/medDbOp.dart';
import 'package:rawya/model/medModel.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:rawya/ui/med/addMed.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:rawya/ui/med/updateMed.dart';
import 'package:rawya/ui/med/viewMed.dart';

import 'listSearchPage.dart';

class HomePage extends StatefulWidget {
  String title;

  HomePage(this.title);

  // ViewUsers({Key key}) : super(key: key,);
  @override
  State<StatefulWidget> createState() => new _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<MedModel> medItems = new List();
  List<String> listOfSearch = [];
  MedDbOp medDbOp = new MedDbOp();

  @override
  void initState() {
    super.initState();
    medDbOp.getAllMeds().then((meds) {
      setState(() {
        meds.forEach((med) {
          medItems.add(MedModel.fromMap(med));
        });
        medItems.forEach((med) {
          setState(
            () {
              listOfSearch.add(med.medName);
              print('---------------------' + med.medName);
            },
          );
        });
      });
    });
  }

  final ScrollController _listeController = ScrollController();
  double _fontText1Size = 20;
  double _fontText2Size = 15;
  double _fontText3Size = 15;
  ScrollController _silverController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NestedScrollView(
        physics: NeverScrollableScrollPhysics(),
        controller: _silverController,
        headerSliverBuilder: (context, innerBoxScrolled) => [
          SliverAppBar(
            title: Text(widget.title),
            centerTitle: true,
            backgroundColor: Colors.deepPurpleAccent,
            actions: <Widget>[
              Builder(
                builder: (context) {
                  return IconButton(
                    icon: Icon(Icons.search),
                    onPressed: () async {
                      String r = await showSearch<String>(
                        context: context,
                        delegate: ListSearchPage(listOfSearch, medItems),
                      );

                      Scaffold.of(context).showSnackBar(
                        SnackBar(
                          content: Text(r),
                          action: SnackBarAction(
                            label: 'CLOSE',
                            onPressed: () {},
                          ),
                        ),
                      );
                    },
                  );
                },
              )
            ],
          )
        ],
        body: Column(
          children: [
            Expanded(
              child: ListView.separated(
                  controller: _listeController,
                  padding: const EdgeInsets.only(bottom: 75),
                  itemCount: medItems.length,
                  separatorBuilder: (BuildContext context, int index) =>
                      Divider(
                        color: Colors.black,
                        height: 2,
                        thickness: 1.5,
                      ),
                  itemBuilder: (context, position) {
                    return InkWell(
                      child: Card(
                        child: Column(
                          children: <Widget>[
                            Divider(height: 5.0),
                            Slidable(
                              actionPane: SlidableDrawerActionPane(),
                              actionExtentRatio: 0.25,
                              actions: <Widget>[
                                IconSlideAction(
                                  caption: 'Delete',
                                  color: Colors.red,
                                  icon: Icons.delete,
                                  onTap: () => _deleteUser(
                                      context, medItems[position], position),
                                ),
                                IconSlideAction(
                                  caption: 'Update',
                                  color: Colors.indigo,
                                  icon: Icons.account_box,
                                  onTap: () => _navigateToUpdateUser(
                                      context, medItems[position]),
                                ),
                              ],
                              child: Column(
                                children: [
                                  Container(
                                    height: 75,
                                    width: double.infinity,
                                    child: Row(
                                      children: [
                                        Expanded(
                                          flex: 10,
                                          child: Container(
                                            height: double.infinity,
                                            width: double.infinity,
                                            child: Align(
                                              alignment: Alignment.center,
                                              child: CircleAvatar(
                                                backgroundColor: Colors.amber,
                                                radius: 15.0,
                                                child: Text(
                                                  '${medItems[position].medId}',
                                                  style: TextStyle(
                                                    fontSize: 22.0,
                                                    color: Colors.redAccent,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 90,
                                          child: Container(
                                            height: double.infinity,
                                            width: double.infinity,
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(15.0),
                                              child: Align(
                                                alignment: Alignment.center,
                                                child: Text(
                                                  '${medItems[position].medName} ',
                                                  style: TextStyle(
                                                    color: Colors.black,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: _fontText1Size,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      onTap: () {
                        _navigateToViewMed(context, medItems[position]);
                      },
                    );
                  }),
            ),
          ],
        ),
      ),
      floatingActionButton: Row(
        children: [
          Expanded(
            flex: 50,
            child: Container(
              margin: const EdgeInsets.only(left: 20.0),
              //  color: Colors.redAccent,
              child: Align(
                alignment: Alignment.bottomLeft,
                child: FloatingActionButton(
                  heroTag: "btn1",
                  backgroundColor: Colors.redAccent,
                  child: Icon(Icons.arrow_upward),
                  onPressed: () => _onTap(0),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 50,
            child: Container(
              //color: Colors.amber,
              child: Align(
                alignment: Alignment.bottomRight,
                child: FloatingActionButton(
                  heroTag: "btn2",
                  backgroundColor: Colors.redAccent,
                  child: Icon(Icons.add),
                  onPressed: () => _navigateToAddNewUser(context),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onTap(int i) {
    _listeController.animateTo(
      0,
      duration: Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
    setState(() {});
  }

  void _deleteUser(BuildContext context, MedModel med, int position) async {
    medDbOp.deletMed(med.medId).then((meds) {
      setState(() {
        medItems.removeAt(position);
      });
    });
  }

  void _navigateToUpdateUser(BuildContext context, MedModel med) async {
    String result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => UpdateMed(med)),
    );

    if (result == 'update') {
      medDbOp.getAllMeds().then((meds) {
        setState(() {
          medItems.clear();
          meds.forEach((med) {
            medItems.add(MedModel.fromMap(med));
          });
        });
      });
    }
  }

  void _navigateToViewMed(BuildContext context, MedModel med) async {
    String result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ViewMed(med)),
    );

    if (result == 'update') {
      medDbOp.getAllMeds().then((meds) {
        setState(() {
          medItems.clear();
          meds.forEach((med) {
            medItems.add(MedModel.fromMap(med));
          });
        });
      });
    }
  }

  void _navigateToAddNewUser(BuildContext context) async {
    String result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddMed()),
    );

    if (result == 'save') {
      medDbOp.getAllMeds().then((meds) {
        setState(() {
          medItems.clear();
          meds.forEach((med) {
            medItems.add(MedModel.fromMap(med));
          });
        });
      });
    }
  }
}
