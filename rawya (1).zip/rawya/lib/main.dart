// @dart=2.9

import 'package:flutter/material.dart';
import 'package:rawya/ui/home/homePage.dart';
import 'package:rawya/ui/med/addMed.dart';

void main() {
  runApp(
    MaterialApp(
      //  title: 'Returning Data',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      debugShowCheckedModeBanner: false,
      home: HomePage('Med Db'),
      //  home: MyApp(),
    ),
  );
}
