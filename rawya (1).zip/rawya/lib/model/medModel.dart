// @dart=2.9
class MedModel {
  int _medId;
  String _medCode;
  String _medName;
  String _laboName;

  MedModel(this._medCode, this._medName, this._laboName);
//nada3 li kol 9ima mifta7 min ajl wad3 hadihi el map fi db
//na9oum bi id5al 9iyam min naw3 dynamic walicol 9iwa no7tiha mifta7
//wa hadihi el 9iyam na9oum bi i7dariha 3an tari9 el getter fi el satr 23
  MedModel.map(dynamic obj) {
    this._medId = obj['medId'];
    this._medCode = obj['medCode'];
    this._medName = obj['medName'];
    this._laboName = obj['laboName'];
  }
//9em bi i7dar el id mina el user wa da3 9imatahou fi el id el metawajid fi el class
//a7dir el bayanat mina el user wada3ha fi meta8ayirat hada el class
  /////hadou homa li n3aytoulhom fi el UI bi el widjet
  int get medId => _medId;
  String get medCode => _medCode;
  String get medName => _medName;
  String get laboName => _laboName;
  //da3 el bayanat fi db
  //el bayanat alati tersal mina el ui ila db yatim ta7witoha ila map 3an tari9 datlat tomap them te5azan
  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
    if (_medId != null) {
      map['medId'] = _medId;
    }
    map['medCode'] = _medCode;
    map['medName'] = _medName;
    map['laboName'] = _laboName;
    return map;
  }

  //i9ra el bayanat mina el db
  //a7dir el map mina el db wa li kel mifta7 x fi el map da3 mayou9abilouhou min 9ima fi meta8ayirat el class
  MedModel.fromMap(Map<String, dynamic> map) {
    this._medId = map['medId'];
    this._medCode = map['medCode'];
    this._medName = map['medName'];
    this._laboName = map['laboName'];
  }
}
