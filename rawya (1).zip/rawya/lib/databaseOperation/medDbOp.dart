// @dart=2.9
import 'package:rawya/database/db_medecament.dart';
import 'package:rawya/model/medModel.dart';
import 'package:sqflite/sqflite.dart';

class MedDbOp {
  final String tableMed = 'tableMedecament';
  final String columnMedId = 'medId';
  final String columnMedCode = 'medCode';
  final String columnMedName = 'medName';
  final String columnLaboName = 'laboName';

  MedDbOp medDbOp;
  final dbProvider = Db_medecament.instance;

  Future<int> addMed(MedModel med) async {
    var dbClient = await dbProvider.db;
    var result = await dbClient.insert(tableMed, med.toMap());

    return result;
  }

  Future<int> updateMed(MedModel med) async {
    var dbClient = await dbProvider.db;
    return await dbClient.update(tableMed, med.toMap(),
        where: "$columnMedId = ?", whereArgs: [med.medId]);
  }

  Future<int> deletMed(int medID) async {
    var dbClient = await dbProvider.db;
    return await dbClient
        .delete(tableMed, where: '$columnMedId = ?', whereArgs: [medID]);
  }

  Future<List> getAllMeds() async {
    var dbClient = await dbProvider.db;
    var result = await dbClient.query(tableMed, columns: [
      columnMedId,
      columnMedCode,
      columnMedName,
      columnLaboName,
    ]);

    return result.toList();
  }

///////////////////////////////laysat mesta5dama fi el code *getCount()
  Future<int> getCount() async {
    var dbClient = await dbProvider.db;
    return Sqflite.firstIntValue(
        await dbClient.rawQuery('SELECT COUNT(*) FROM $tableMed'));
  }

  Future<MedModel> getMed(int medId) async {
    var dbClient = await dbProvider.db;
    List<Map> result = await dbClient.query(tableMed,
        columns: [
          columnMedId,
          columnMedCode,
          columnMedName,
          columnLaboName,
        ],
        where: '$columnMedId = ?',
        whereArgs: [medId]);

    if (result.length > 0) {
      return new MedModel.fromMap(result.first);
    }

    return null;
  }

  Future close() async {
    var dbClient = await dbProvider.db;
    return dbClient.close();
  }

  Future<List<MedModel>> searchMed(String keyword) async {
    final db = await dbProvider.db;
    List<Map<String, dynamic>> allRows = await db
        .query(tableMed, where: 'medName LIKE ?', whereArgs: ['%$keyword%']);
    List<MedModel> meds = allRows.map((med) => MedModel.fromMap(med)).toList();

    print('-----------------------keyword $keyword');
    print('-----------------------');

    if (meds.length > 0) {
      print('--------------------OK');
      meds.forEach((med) {
        print('---------------- ${med.medName}');
      });
    } else {
      print('--------------------NO');
    }

    return meds;
  }
}

//WHERE name LIKE 'keyword%'
//--Finds any values that start with "keyword"
//WHERE name LIKE '%keyword'
//--Finds any values that end with "keyword"
//WHERE name LIKE '%keyword%'
//--Finds any values that have "keyword" in any position
