// @dart=2.9
import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
//import 'package:intl/intl.dart';

class Db_medecament {
  Db_medecament.privateConstructor();

  static final Db_medecament instance = Db_medecament.privateConstructor();
  //////////////////////////table Users
  final String tableMed = 'tableMedecament';

  final String columnMedId = 'medId';
  final String columnMedCode = 'medCode';
  final String columnMedName = 'medName';
  final String columnLaboName = 'laboName';

  static Database _db;

  //hadihi el talla ta9oum bi jald el db mina el dala intDb fi 7alat anou el db lam tencha
  Future<Database> get db async {
    if (_db != null) {
      return _db;
    }
    _db = await initDb();

    return _db;
  }

//incha el dibi wa irja3ouha ila el dalla  Future<Database> get db async
  initDb() async {
    String databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'reawya.db');

    var db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return db;
  }

  void _onCreate(Database db, int newVersion) async {
    await db.execute('CREATE TABLE $tableMed('
        '$columnMedId INTEGER PRIMARY KEY, '
        '$columnMedCode TEXT NOT NULL , '
        '$columnMedName TEXT NOT NULL,'
        ' $columnLaboName TEXT NOT NULL)');

    await db.execute(
        "INSERT INTO $tableMed ('$columnMedId', '$columnMedCode', '$columnMedName', '$columnLaboName') values (?, ?, ?, ?)",
        [1, "a125", "Paralgan", "Labo1"]);
  }
}
