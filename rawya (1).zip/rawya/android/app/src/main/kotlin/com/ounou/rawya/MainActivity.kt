package com.ounou.rawya

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
